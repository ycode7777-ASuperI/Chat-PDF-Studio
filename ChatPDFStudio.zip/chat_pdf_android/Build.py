import regex
import os
import ast
import zipfile
import tempfile
from fpdf import FPDF
from fpdf.enums import XPos, YPos
from itertools import islice, chain
import unicodedata
import concurrent.futures

PATTERN = regex.compile(pattern=r"\A(?P<day>\d{1,2})/(?P<month>\d{1,2})/(?P<year>\d{2,4}),\s(?P<hours>\d{1,2}):(?P<minutes>\d{1,2})")
DATE_PATTERN = regex.compile(pattern=r"(?P<day>\d{1,2})(?:st|nd|rd|th)?[-/,.\s]*(?P<month>\d{1,2}|\w{2,})[-/,.\s]*(?P<year>\d{2,4})",flags=regex.I|regex.U)
KEYWORD_PATTERN = regex.compile(pattern=r"\b(birth|जन्म तारीख़|जन्म तारीख|जन्म|d. o. b.|d b.|dob|d.o.b.|d.0.b.|जन्म ता|जन्मतारीख|जन्मतारिख|जन्म दिनांक)\b",flags=regex.I)
NAME_PATTERN = regex.compile(pattern=r"\b(संपूर्ण नांव|संपूर्ण नाव|नांव|नाव|name)(?:[^\p{Script=Devanagari}A-Za-z0-9]+)",flags=regex.I)
YEAR_PATTERN = regex.compile(r"[0][0-9]")
IMAGE_PATTERN = regex.compile(r"IMG-\d{8}-\w{6}\.\w[A-Za-z]+")
INFO_PATTERN = regex.compile(pattern=r"\b(गोत्र|रास|गण|नक्षत्र|नौकरी|नोकरी|Salary|Job)[^\p{Script=Devanagari}A-Za-z0-9]+",flags=regex.I)
SAFE_TEXT_PATTERN = regex.compile(r'[^\p{L}\p{M}\p{N}\p{P}\p{Z}]+', flags=regex.V1)

def parse_filter_year(start_year, end_year):
    if start_year is None and end_year is None:
        return lambda y: True
    elif end_year is None:
        return lambda y: y >= start_year
    elif start_year is None:
        return lambda y: y <= end_year
    else:
        return lambda y: start_year <= y <= end_year

def time_bound(current_stamp, target_stamp):
    current_date, current_time = current_stamp.split(", ")
    try:
        target_date, target_time = target_stamp.split(", ")
    except:
        return None
    if current_date == target_date:
        tt = int(target_time.split(":")[1])
        ct = int(current_time.split(":")[1])
        if tt == ct - 1:
            return True
        elif tt == ct + 1:
            return True
        elif tt == ct:
            return True
        else:
            return False

def _normalize_person_name(value):
    """Normalize a biodata name for reliable duplicate detection."""
    return " ".join(str(value or "").split()).casefold()


def _processed_names_path(zip_path, original_filename=None, processed_names_dir=None):
    persistent_dir = processed_names_dir or os.path.join(tempfile.gettempdir(), "processed_names")
    os.makedirs(persistent_dir, exist_ok=True)
    identifier = original_filename or os.path.basename(zip_path)
    archive_name = os.path.basename(str(identifier).replace("\\", "/"))
    archive_stem = os.path.splitext(archive_name)[0]
    safe_stem = "".join(c for c in archive_stem if c.isalnum() or c in "-_.").strip("._") or "archive"
    new_path = os.path.join(persistent_dir, f"{safe_stem}_names.txt")

    # Migrate the old convention, e.g. Family.zip_names.txt, once.
    safe_legacy = "".join(c for c in archive_name if c.isalnum() or c in "-_.")
    legacy_path = os.path.join(persistent_dir, f"{safe_legacy}_names.txt")
    if not os.path.exists(new_path) and os.path.isfile(legacy_path):
        os.replace(legacy_path, new_path)
    return new_path

def extract_valuable_data(file, zip_path, max_entries, max_pdfs, start_year, end_year, progress_callback=None, original_filename=None, track_processed_names=True, processed_names_dir=None, names_to_add=None):
    allowed = False
    year_condition = parse_filter_year(start_year=start_year, end_year=end_year)
    list_of_coords = []
    pdf_list = []
    state_index = None
    date_state = None
    last_index = 0
    text_start = 0
    text_line = 0
    image_location = None
    is_info = None
    date_stamp = None
    is_named_found = None
    named_string = None
    names_set = set()

    persistent_dir = processed_names_dir or os.path.join(tempfile.gettempdir(), "processed_names")
    os.makedirs(persistent_dir, exist_ok=True)
    if track_processed_names:
        output_name_file = _processed_names_path(zip_path, original_filename, persistent_dir)
    else:
        # Temporary tracking is useful for one-off desktop runs that should not
        # consult or persist a prior archive's name list.
        fd, output_name_file = tempfile.mkstemp(prefix="chatpdf_temp_names_", suffix=".txt", dir=persistent_dir)
        os.close(fd)

    total_size = os.path.getsize(file)
    bytes_read = 0

    if not os.path.exists(output_name_file):
        open(output_name_file, 'w', encoding='utf-8').close()

    with (
        open(file=file, mode="r", encoding="utf-8") as file_stream,
        open(file=output_name_file, mode="a+", encoding="utf-8") as storage_file
    ):
        storage_file.seek(0)
        read_set = storage_file.read()
        if read_set and read_set.strip() != "set()":
            try:
                saved_names = ast.literal_eval(read_set)
                if isinstance(saved_names, (set, list, tuple)):
                    names_set = {_normalize_person_name(name) for name in saved_names}
                else:
                    names_set = set()
            except Exception:
                names_set = set()

        actual_index = 0

        for line in file_stream:
            bytes_read += len(line.encode('utf-8'))
            if actual_index % 5000 == 0 and progress_callback is not None:
                percent = min(100.0, (bytes_read / total_size) * 100)
                progress_callback({
                    "stage": "scanning", 
                    "percent": percent, 
                    "message": f"Scanning chat data... {int(percent)}%"
                })
            stripped_line = line.strip()

            is_matched = PATTERN.match(stripped_line)
            is_named = NAME_PATTERN.search(string=stripped_line)

            if is_matched:
                current_stamp = f"{is_matched.group('day')}/{is_matched.group('month')}/{is_matched.group('year')}, {is_matched.group('hours')}:{is_matched.group('minutes')}"
                is_perfect_time = time_bound(target_stamp=date_stamp, current_stamp=current_stamp)

                if state_index is not None and date_state and is_info:
                    if allowed:
                        if is_perfect_time and "IMG" in stripped_line:
                            image_location = IMAGE_PATTERN.search(string=stripped_line).group()

                        img_val = image_location if image_location else "NO_IMAGE"
                        # Biodata without a matching image is intentionally excluded.
                        if img_val != "NO_IMAGE":
                            pdf_list.append((text_line, text_start, actual_index - 1, img_val))
                            if named_string:
                                names_set.add(_normalize_person_name(named_string))
                                if names_to_add is not None:
                                    names_to_add.append(named_string)
                        
                    allowed = False
                    state_index = None
                    date_state = None
                    image_location = None
                    text_start = 0
                    text_line = 0
                    is_named_found = None
                    named_string = None

                elif state_index is not None and date_state is None:
                    if current_stamp != date_stamp:
                        image_location = None
                    allowed = False
                    state_index = None
                    date_state = None
                    text_start = 0
                    text_line = 0
                    is_named_found = None
                    named_string = None

                if image_location and current_stamp != date_stamp:
                    image_location = None

                if "IMG" in stripped_line:
                    try:
                        image_location = IMAGE_PATTERN.search(string=stripped_line).group()
                    except Exception:
                        pass
                    state_index = actual_index
                    text_start = 0
                    text_line = state_index

                if is_named:
                    state_index = actual_index
                    text_line = actual_index
                    text_start = is_named.start()
                    text_end = is_named.end()
                    is_named_found = True
                    named_string = stripped_line[text_end:].strip()

                date_stamp = current_stamp
            else:
                last_index = actual_index

            if is_named and (state_index is None or is_named_found is None):
                if state_index is None:
                    state_index = actual_index
                text_start = is_named.start()
                text_end = is_named.end()
                text_line = actual_index
                is_named_found = True
                named_string = stripped_line[text_end:].strip()

            lines_consumed_by_islice = 0
            if KEYWORD_PATTERN.search(string=stripped_line):
                next_lines = list(islice(file_stream, 1))
                lines_consumed_by_islice = len(next_lines)
                sub_string = [i.strip() for i in chain([stripped_line], next_lines)]
                safe_string = " ".join(sub_string)
                matched = DATE_PATTERN.search(string=safe_string)
                if matched:
                    year_str = matched.group("year")
                    if len(year_str) == 2:
                        year = int("20" + year_str) if YEAR_PATTERN.fullmatch(string=year_str) else int("19" + year_str)
                    else:
                        year = int(year_str)

                    if year_condition(year):
                        date_state = True

            is_info_true = INFO_PATTERN.search(string=stripped_line)
            if is_info is None and is_info_true:
                is_info = True

            actual_index += 1 + lines_consumed_by_islice

            if named_string and date_state:
                # Reserve names only after a valid, image-bearing biodata block
                # has actually been added to a PDF chunk.
                allowed = _normalize_person_name(named_string) not in names_set

            if max_entries is not None and len(pdf_list) == max_entries:
                list_of_coords.append(pdf_list)
                pdf_list = []
            if max_pdfs is not None and len(list_of_coords) == max_pdfs:
                break

        if state_index is not None and date_state and is_info:
            if allowed:
                img_val = image_location if image_location else "NO_IMAGE"
                if img_val != "NO_IMAGE":
                    pdf_list.append((text_line, text_start, last_index, img_val))
                    if named_string:
                        names_set.add(named_string)
                        if names_to_add is not None:
                            names_to_add.append(named_string)

        if len(list_of_coords) == 0 or (0 < len(pdf_list) and (max_entries is None or len(pdf_list) < max_entries)):
            list_of_coords.append(pdf_list)

        # Do not persist newly discovered names here: PDF generation has not
        # succeeded yet. main() commits them only after every output is written.

    if not track_processed_names:
        try:
            os.remove(output_name_file)
        except OSError:
            pass

    if progress_callback is not None:
        progress_callback({"stage": "scanning", "percent": 100.0, "message": "Scanning chat data... 100%"})

    return list_of_coords

def generate_pdf(base_output_pdf_name, source_file_path, image_folder_path, extracted_data, font_dir=None):
    written_paths = []
    if not os.path.exists(source_file_path):
        raise FileNotFoundError(f"Source file not found at: {source_file_path}")
        
    with open(source_file_path, 'r', encoding='utf-8') as f:
        file_lines = f.readlines()

    # Fonts are supplied by the Android adapter (or kept beside this module on desktop).
    font_dir = font_dir or os.path.dirname(os.path.abspath(__file__))
    font_reg = os.path.join(font_dir, "NotoSansDevanagari-Regular.ttf")
    font_bld = os.path.join(font_dir, "NotoSansDevanagari-Bold.ttf")
    if not os.path.isfile(font_reg) or not os.path.isfile(font_bld):
        raise FileNotFoundError(
            "Required Devanagari fonts are missing. Add NotoSansDevanagari-Regular.ttf "
            "and NotoSansDevanagari-Bold.ttf to the configured font directory: " + font_dir
        )

    PAGE_WIDTH = 215.9
    PAGE_HEIGHT = 279.4
    CARD_MARGIN = 15
    CARD_WIDTH = PAGE_WIDTH - (CARD_MARGIN * 2)
    CARD_HEIGHT = PAGE_HEIGHT - (CARD_MARGIN * 2)

    for pdf_idx, pdf_chunk in enumerate(extracted_data):
        if not pdf_chunk:
            continue
            
        pdf = FPDF(orientation="P", unit="mm", format="letter")
        pdf.set_auto_page_break(auto=False) 
        
        pdf.add_font("NotoMarathi", style="", fname=font_reg)
        pdf.add_font("NotoMarathi", style="B", fname=font_bld)
        FONT_FAMILY = "NotoMarathi"

        for block_idx, block_tuple in enumerate(pdf_chunk):
            start_line_idx, char_offset, end_line_idx, image_name = block_tuple
            pdf.add_page()
            
            pdf.set_fill_color(15, 23, 42)
            pdf.rect(0, 0, PAGE_WIDTH, PAGE_HEIGHT, style="F")
            
            pdf.set_fill_color(51, 65, 85)
            pdf.rect(x=CARD_MARGIN, y=CARD_MARGIN, w=CARD_WIDTH, h=CARD_HEIGHT, style="F", round_corners=True)

            current_y = CARD_MARGIN + 15
            
            if image_name and image_name.upper() != "NO_IMAGE":
                full_image_path = os.path.join(image_folder_path, image_name)
                if os.path.exists(full_image_path):
                    img_w = 60
                    img_h = 75
                    img_x = (PAGE_WIDTH - img_w) / 2
                    img_y = CARD_MARGIN + 15
                    pdf.image(full_image_path, x=img_x, y=img_y, w=img_w, h=img_h)
                    current_y = img_y + img_h + 15

            pdf.set_y(current_y)
            text_margin = CARD_MARGIN + 10
            text_printable_width = CARD_WIDTH - 20
            
            for idx in range(start_line_idx, end_line_idx + 1):
                if idx >= len(file_lines):
                    break
                current_line = file_lines[idx]
                if "(file attached)" in current_line or IMAGE_PATTERN.search(current_line):
                    continue
                if idx == start_line_idx:
                    current_line = current_line[char_offset:]

                raw_clean = SAFE_TEXT_PATTERN.sub(' ', current_line)
                cleaned_line = " ".join(raw_clean.split())
                if not cleaned_line:
                    continue
                    
                pdf.set_text_color(248, 250, 252) 
                pdf.set_x(text_margin)
                
                if cleaned_line.startswith('*') and cleaned_line.endswith('*'):
                    header_text = cleaned_line.replace('*', '')
                    pdf.set_font(FONT_FAMILY, style="B", size=14)
                    pdf.ln(4)
                    pdf.set_x(text_margin)
                    pdf.multi_cell(w=text_printable_width, h=8, text=header_text, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
                    pdf.ln(2)
                else:
                    pdf.set_font(FONT_FAMILY, style="", size=11)
                    if '*' in cleaned_line:
                        parts = cleaned_line.split('*')
                        for p_idx, part in enumerate(parts):
                            if p_idx % 2 == 1:
                                pdf.set_font(FONT_FAMILY, style="B", size=11)
                            else:
                                pdf.set_font(FONT_FAMILY, style="", size=11)
                            pdf.write(h=7, text=part)
                        pdf.ln(7)
                    else:
                        pdf.multi_cell(w=text_printable_width, h=7, text=cleaned_line, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                        
                if pdf.get_y() > (PAGE_HEIGHT - CARD_MARGIN - 15):
                    pdf.add_page()
                    pdf.set_fill_color(15, 23, 42)
                    pdf.rect(0, 0, PAGE_WIDTH, PAGE_HEIGHT, style="F")
                    pdf.set_fill_color(51, 65, 85)
                    pdf.rect(x=CARD_MARGIN, y=CARD_MARGIN, w=CARD_WIDTH, h=CARD_HEIGHT, style="F", round_corners=True)
                    pdf.set_y(CARD_MARGIN + 15)

        if len(extracted_data) > 1:
            dynamic_pdf_name = base_output_pdf_name.replace(".pdf", f"_{pdf_idx + 1}.pdf")
        else:
            dynamic_pdf_name = base_output_pdf_name
            
        pdf.output(dynamic_pdf_name)
        written_paths.append(dynamic_pdf_name)

    return written_paths

def main(zip_path, source_folder, num_of_entries=None, max_pdfs=None, start_year=None, end_year=None,
         base_name="Generated_Report", progress_callback=None, max_workers=None, original_filename=None,
         font_dir=None, track_processed_names=True, processed_names_dir=None):
    def _report(event):
        if progress_callback is not None:
            progress_callback(event)

    norm_source_folder = unicodedata.normalize("NFC", os.path.normpath(source_folder))
    os.makedirs(norm_source_folder, exist_ok=True)

    text_file_path = None
    _report({"stage": "extracting", "message": "Safely extracting text data..."})
    
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        for file_info in zip_ref.infolist():
            norm_filename = unicodedata.normalize("NFC", file_info.filename)
            if norm_filename.endswith(".txt") and not norm_filename.endswith("_names.txt"):
                zip_ref.extract(file_info, norm_source_folder)
                text_file_path = os.path.join(norm_source_folder, file_info.filename)
                break

    if not text_file_path:
        raise FileNotFoundError("No '.txt' file found inside the archive.")

    _report({"stage": "scanning", "message": "Scanning chat data (this takes a moment for large files)..."})
    names_to_add = []
    list_of_pdfs = extract_valuable_data(
        file=text_file_path,
        zip_path=zip_path,
        max_entries=num_of_entries,
        max_pdfs=max_pdfs,
        start_year=start_year,
        end_year=end_year,
        progress_callback=progress_callback,
        original_filename=original_filename,
        track_processed_names=track_processed_names,
        processed_names_dir=processed_names_dir,
        names_to_add=names_to_add,
    )

    if not list_of_pdfs or not any(list_of_pdfs):
        registry_path = _processed_names_path(zip_path, original_filename, processed_names_dir)
        registry_has_names = False
        try:
            with open(registry_path, "r", encoding="utf-8") as registry:
                saved = registry.read().strip()
            parsed = ast.literal_eval(saved) if saved else set()
            registry_has_names = isinstance(parsed, (set, list, tuple)) and bool(parsed)
        except Exception:
            registry_has_names = False
        if registry_has_names:
            raise ValueError("ALREADY_PROCESSED:तुम्ही या झिप (zip) फाईलमधून आधीच पीडीएफ (PDFs) तयार केली आहेत.")
        raise ValueError("या वर्षांच्या मर्यादेत PDF तयार करण्यासाठी पात्र डेटा सापडला नाही.")

    _report({"stage": "extracting", "message": "Fetching required images..."})
    required_images = set()
    for pdf_chunk in list_of_pdfs:
        for block in pdf_chunk:
            img = block[3]
            if img and img != "NO_IMAGE":
                required_images.add(img)

    if required_images:
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            file_map = {os.path.basename(f): f for f in zip_ref.namelist()}
            for img_name in required_images:
                if img_name in file_map:
                    zip_ref.extract(file_map[img_name], norm_source_folder)

    total_chunks = len(list_of_pdfs)
    all_written_paths = []
    errors = []

    # ThreadPoolExecutor is compatible with Chaquopy/Android; Android does not
    # provide the process/IPC environment required by ProcessPoolExecutor.
    worker_count = max(1, int(max_workers or 1))
    with concurrent.futures.ThreadPoolExecutor(max_workers=worker_count) as executor:
        future_to_index = {}
        if start_year is not None and end_year is not None:
            year_suffix = f"_{start_year}_{end_year}"
        elif start_year is not None:
            year_suffix = f"_{start_year}_onward"
        elif end_year is not None:
            year_suffix = f"_until_{end_year}"
        else:
            year_suffix = ""

        for i, pdf_data in enumerate(list_of_pdfs):
            chunk_suffix = f"_{i+1}" if total_chunks > 1 else ""
            pdf_name = f"{base_name}{chunk_suffix}{year_suffix}.pdf"
            output_path = os.path.join(norm_source_folder, pdf_name)
            
            future = executor.submit(
                generate_pdf,
                output_path,
                text_file_path,
                norm_source_folder, 
                [pdf_data],
                font_dir
            )
            future_to_index[future] = i

        completed = 0
        for future in concurrent.futures.as_completed(future_to_index):
            completed += 1
            try:
                written = future.result()
                all_written_paths.extend(written)
            except Exception as e:
                errors.append(str(e))
            _report({"stage": "generating", "completed": completed, "total": total_chunks})

    if not all_written_paths:
        raise RuntimeError("No PDFs produced. Errors: " + ("; ".join(errors) if errors else "Unknown Error"))

    # Commit only when every PDF chunk completed. This prevents a failed or
    # partially completed generation from marking biodata as already processed.
    if track_processed_names and names_to_add and not errors:
        names_file = _processed_names_path(zip_path, original_filename, processed_names_dir)
        existing_names = set()
        if os.path.isfile(names_file):
            try:
                with open(names_file, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                if content:
                    parsed = ast.literal_eval(content)
                    if isinstance(parsed, (set, list, tuple)):
                        existing_names = set(parsed)
            except Exception:
                existing_names = set()
        existing_names.update(names_to_add)
        temporary_names_file = names_file + ".tmp"
        with open(temporary_names_file, "w", encoding="utf-8") as f:
            f.write(repr(existing_names))
        os.replace(temporary_names_file, names_file)

    _report({"stage": "done", "paths": all_written_paths, "errors": errors})
    return all_written_paths
