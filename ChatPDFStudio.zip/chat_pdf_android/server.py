import unicodedata
import asyncio
import json
import os
import queue
import re
import shutil
import tempfile
import threading
import time
import uuid
import zipfile
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from starlette.background import BackgroundTask

from Build import main as execute_pdf_pipeline

app = FastAPI(title="Chat PDF Studio")

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"
HTML_FILE = TEMPLATES_DIR / "index.html"
WORK_DIR = Path(os.environ.get("WORK_DIR", tempfile.gettempdir())) / "chat_pdf_studio"
UPLOADS_DIR = WORK_DIR / "uploads"
DOWNLOADS_DIR = WORK_DIR / "downloads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)

CHUNK_SIZE_LIMIT_BYTES = 10 * 1024 * 1024
HEARTBEAT_INTERVAL_SECONDS = 5

def _safe_id(value: str) -> str:
    return "".join(c for c in value if c.isalnum() or c in "-_")

def _cpu_budget() -> int:
    try:
        return max(1, len(os.sched_getaffinity(0)))
    except AttributeError:
        return max(1, os.cpu_count() or 1)

@app.get("/", response_class=HTMLResponse)
async def serve_interface():
    if not HTML_FILE.exists():
        raise HTTPException(status_code=500, detail="UI file is missing from the deployment.")
    return HTMLResponse(content=HTML_FILE.read_text(encoding="utf-8"), headers={"Cache-Control": "no-store"})

@app.post("/upload-chunk")
async def upload_chunk(
    upload_id: str = Form(...),
    chunk_index: int = Form(...),
    total_chunks: int = Form(...),
    chunk: UploadFile = File(...),
):
    safe_id = _safe_id(upload_id)
    if not safe_id:
        raise HTTPException(status_code=400, detail="Invalid upload_id.")
    if chunk_index < 0 or total_chunks < 1 or chunk_index >= total_chunks:
        raise HTTPException(status_code=400, detail="Invalid chunk index.")

    upload_dir = UPLOADS_DIR / safe_id
    upload_dir.mkdir(parents=True, exist_ok=True)

    data = await chunk.read()
    if len(data) > CHUNK_SIZE_LIMIT_BYTES:
        raise HTTPException(status_code=413, detail="Chunk size exceeded limit.")

    part_path = upload_dir / f"chunk-{chunk_index:08d}.part"
    tmp_path = upload_dir / f"chunk-{chunk_index:08d}.tmp"
    try:
        tmp_path.write_bytes(data)
        os.replace(tmp_path, part_path)
        (upload_dir / "meta.json").write_text(
            json.dumps({"total_chunks": total_chunks}, separators=(",", ":")),
            encoding="utf-8",
        )
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)

    return {"status": "success"}

def _assemble_upload(safe_id: str, total_chunks: int) -> Path:
    upload_dir = UPLOADS_DIR / safe_id
    if not upload_dir.is_dir():
        raise FileNotFoundError("Upload session was not found.")

    archive_path = WORK_DIR / f"{safe_id}.zip"
    tmp_archive = WORK_DIR / f"{safe_id}.zip.tmp"
    with open(tmp_archive, "wb") as out:
        for index in range(total_chunks):
            part = upload_dir / f"chunk-{index:08d}.part"
            if not part.exists():
                raise FileNotFoundError(f"Missing chunk {index + 1}.")
            with open(part, "rb") as src:
                shutil.copyfileobj(src, out, length=1024 * 1024)
    os.replace(tmp_archive, archive_path)
    shutil.rmtree(upload_dir, ignore_errors=True)
    return archive_path

def _cleanup_paths(*paths: Path):
    for path in paths:
        try:
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
            elif path.exists():
                path.unlink(missing_ok=True)
        except Exception:
            pass

@app.post("/process")
async def process_chat_export(
    upload_id: str = Form(...),
    original_filename: str = Form(...),
    total_chunks: Optional[int] = Form(None),
    start_year: Optional[int] = Form(None),
    end_year: Optional[int] = Form(None),
    num_entries: Optional[int] = Form(None),
    max_pdfs: Optional[int] = Form(None),
    base_name: str = Form("Generated_Report"),
):
    safe_id = _safe_id(upload_id)
    upload_dir = UPLOADS_DIR / safe_id
    if total_chunks is None:
        meta = upload_dir / "meta.json"
        if meta.exists():
            try:
                total_chunks = int(json.loads(meta.read_text(encoding="utf-8"))["total_chunks"])
            except Exception:
                pass

    try:
        zip_path = _assemble_upload(safe_id, total_chunks)
    except FileNotFoundError as exc:
        print(f'Assembly error: {exc}')
        raise HTTPException(status_code=400, detail=f'Upload assembly failed: {str(exc)}')

    job_dir = Path(tempfile.mkdtemp(dir=WORK_DIR, prefix=f"job_{safe_id}_"))
    normalized_base = unicodedata.normalize("NFC", base_name)
    safe_base_name = "".join(c for c in normalized_base if c.isalnum() or unicodedata.category(c) in ("Mn", "Mc") or ("\u0900" <= c <= "\u097F") or c in "-_ ").strip().replace(" ", "_") or "Generated_Report"

    def event_stream():
        progress_q: queue.Queue = queue.Queue()
        result_holder = {}

        def emit(event):
            progress_q.put(event)

        def worker():
            try:
                original_name = Path(original_filename).stem
                extract_folder = job_dir / original_name
                
                written_paths = execute_pdf_pipeline(
                    zip_path=str(zip_path),
                    source_folder=str(extract_folder),
                    start_year=start_year,
                    end_year=end_year,
                    num_of_entries=num_entries,
                    max_pdfs=max_pdfs,
                    base_name=safe_base_name,
                    progress_callback=emit,
                    max_workers=_cpu_budget(),
                    original_filename=original_filename,
                )
                result_holder["paths"] = [Path(p) for p in (written_paths or [])]
            except Exception as exc:
                result_holder["error"] = str(exc)
            finally:
                progress_q.put(None)

        threading.Thread(target=worker, daemon=True).start()
        last_event_time = time.monotonic()

        while True:
            try:
                event = progress_q.get(timeout=HEARTBEAT_INTERVAL_SECONDS)
                last_event_time = time.monotonic()
            except queue.Empty:
                yield (json.dumps({"stage": "heartbeat", "message": "Still working..."}) + "\n").encode()
                continue

            if event is None:
                break
            yield (json.dumps(event) + "\n").encode()

        if "error" in result_holder:
            yield (json.dumps({"stage": "error", "message": result_holder["error"]}) + "\n").encode()
            _cleanup_paths(zip_path, job_dir)
            return

        paths = result_holder.get("paths") or []
        try:
            emit({"stage": "packaging", "message": "Preparing download..."})
            download_id = uuid.uuid4().hex
            
            if len(paths) == 1:
                output_path = paths[0]
                download_name = output_path.name
            else:
                output_path = DOWNLOADS_DIR / f"{download_id}_{safe_base_name}_Archive.zip"
                with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as archive:
                    for path in paths:
                        archive.write(path, path.name)
                download_name = f"{safe_base_name}_Archive.zip"

            final_path = DOWNLOADS_DIR / f"{download_id}_{download_name}"
            if output_path != final_path:
                shutil.copy2(output_path, final_path)

            yield (json.dumps({
                "stage": "done",
                "filename": download_name,
                "download_url": f"/download/{download_id}/{quote(download_name)}"
            }) + "\n").encode()
        finally:
            _cleanup_paths(zip_path, job_dir)

    return StreamingResponse(event_stream(), media_type="application/x-ndjson", headers={"Cache-Control": "no-store"})

import asyncio
from urllib.parse import quote, unquote
from fastapi.responses import StreamingResponse

async def _delayed_cleanup(path, delay: int = 600):
    """Waits 10 minutes (600s) before deleting the zip file so mobile browsers can finish downloading."""
    await asyncio.sleep(delay)
    _cleanup_paths(path)

@app.get("/download/{download_id}/{filename}")
async def download_result(download_id: str, filename: str):
    safe_download_id = _safe_id(download_id)
    candidates = list(DOWNLOADS_DIR.glob(f"{safe_download_id}_*"))
    if not candidates:
        raise HTTPException(status_code=404, detail="Download is no longer available.")
    
    target_path = candidates[0]
    file_size = target_path.stat().st_size
    
    # Schedule deletion 10 minutes in the future instead of immediately
    asyncio.create_task(_delayed_cleanup(target_path, 600))
    
    # Stream the file in 1MB (1024 * 1024 bytes) chunks
    def iterfile():
        with open(target_path, "rb") as f:
            while chunk := f.read(1024 * 1024):
                yield chunk

    clean_filename = unquote(filename)
    encoded_filename = quote(clean_filename)
    headers = {
        "Content-Disposition": f'attachment; filename="{encoded_filename}"; filename*=UTF-8\'\'{encoded_filename}',
        "Accept-Ranges": "bytes"
    }
    media_type = "application/zip" if target_path.name.endswith(".zip") else "application/pdf"
    return StreamingResponse(iterfile(), media_type=media_type, headers=headers)

from fastapi.responses import FileResponse

# Serve PWA Manifest
@app.get('/manifest.json')
async def serve_manifest():
    return FileResponse(TEMPLATES_DIR / 'manifest.json', media_type='application/manifest+json')

# Serve PWA Service Worker
@app.get('/sw.js')
async def serve_sw():
    return FileResponse(TEMPLATES_DIR / 'sw.js', media_type='application/javascript')
