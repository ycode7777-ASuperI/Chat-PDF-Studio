package com.example.chatpdfstudio

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var selectedZip: File? = null
    private var selectedOriginalName = "chat_export.zip"
    private var busy = false
    private var pendingSaveFile: File? = null

    private val openZipLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) lifecycleScope.launch { importSelectedZip(uri) }
    }
    private val savePdfLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri: Uri? -> completeSave(uri) }
    private val saveZipLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? -> completeSave(uri) }

    private fun completeSave(uri: Uri?) {
        val source = pendingSaveFile
        pendingSaveFile = null
        if (uri == null || source == null) return
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    contentResolver.openOutputStream(uri, "w")?.use { out -> source.inputStream().use { it.copyTo(out) } }
                        ?: error("Could not open the selected save location.")
                }
                toastToPage("Saved ${source.name}")
            } catch (e: Exception) {
                toastToPage("Save failed: ${e.message ?: "Unknown error"}")
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this); setContentView(webView)
        webView.settings.javaScriptEnabled = true; webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true; webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient(); webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }
    inner class AndroidBridge {
        @JavascriptInterface fun chooseZip() { runOnUiThread { if (!busy) openZipLauncher.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun processArchive(optionsJson: String) { runOnUiThread { if (!busy) startLocalProcessing(runCatching { JSONObject(optionsJson) }.getOrElse { JSONObject() }) } }
        @JavascriptInterface fun saveOutput(path: String, filename: String) {
            runOnUiThread {
                val f = File(path)
                if (!f.isFile) {
                    toastToPage("Generated file could not be found.")
                } else {
                    pendingSaveFile = f
                    val suggestedName = filename.ifBlank { f.name }
                    if (suggestedName.lowercase().endsWith(".zip")) saveZipLauncher.launch(suggestedName)
                    else savePdfLauncher.launch(suggestedName)
                }
            }
        }
        @JavascriptInterface fun savePdf(path: String, filename: String) = saveOutput(path, filename)
    }
    private suspend fun importSelectedZip(uri: Uri) {
        try {
            val displayName=queryDisplayName(uri) ?: "chat_export.zip"
            val target=withContext(Dispatchers.IO) {
                val dir=File(filesDir,"chat_pdf_studio/input").apply { mkdirs() }
                val safe=displayName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._ -]"),"_")
                val name=if(safe.lowercase().endsWith(".zip")) safe else "$safe.zip"
                val out=File(dir,"${System.currentTimeMillis()}_$name")
                contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(out).use { input.copyTo(it) } } ?: error("Android could not read the selected file.")
                val sig=out.inputStream().use { input -> ByteArray(4).also { input.read(it) } }
                val valid=sig.size>=2 && sig[0]==0x50.toByte() && sig[1]==0x4b.toByte()
                if (!valid) { out.delete(); throw IllegalArgumentException("The selected file is not a valid ZIP archive. Choose the original .zip export.") }
                out
            }
            selectedZip=target; selectedOriginalName=displayName
            val quoted=JSONObject.quote(displayName)
            runOnUiThread { webView.evaluateJavascript("window.onNativeFileSelected($quoted, ${target.length()});",null) }
        } catch(e: Exception) { val q=JSONObject.quote("File selection failed: ${e.message ?: "Unknown error"}"); runOnUiThread { webView.evaluateJavascript("window.onNativeError($q);",null) } }
    }
    private fun startLocalProcessing(options: JSONObject) {
        val zip=selectedZip
        if(zip==null || !zip.isFile) { sendError("Please select a .zip archive first."); return }
        val start=options.optString("startYear").toIntOrNull(); val end=options.optString("endYear").toIntOrNull()
        val entries=options.optString("numEntries").toIntOrNull(); val maxPdfs=options.optString("maxPdfs").toIntOrNull()
        val base=options.optString("baseName","Generated_Report").ifBlank { "Generated_Report" }
        if(start!=null && end!=null && start>end) { sendError("Start year cannot be greater than end year."); return }
        if((entries!=null && entries<=0)||(maxPdfs!=null && maxPdfs<=0)) { sendError("Entry and PDF limits must be positive numbers."); return }
        busy=true
        lifecycleScope.launch {
            val job=File(filesDir,"chat_pdf_studio/jobs/${System.currentTimeMillis()}"); val out=File(job,"output").apply { mkdirs() }
            val fonts=File(filesDir,"chat_pdf_studio/fonts").apply { mkdirs() }; val progress=File(job,"progress.json")
            try {
                withContext(Dispatchers.IO) { copyAsset("fonts/NotoSansDevanagari-Regular.ttf",File(fonts,"NotoSansDevanagari-Regular.ttf")); copyAsset("fonts/NotoSansDevanagari-Bold.ttf",File(fonts,"NotoSansDevanagari-Bold.ttf")) }
                if(!File(fonts,"NotoSansDevanagari-Regular.ttf").isFile || !File(fonts,"NotoSansDevanagari-Bold.ttf").isFile) error("Font files missing: add both NotoSansDevanagari-Regular.ttf and NotoSansDevanagari-Bold.ttf to app/src/main/assets/fonts/ before rebuilding.")
                if(!Python.isStarted()) Python.start(AndroidPlatform(this@MainActivity))
                val backend=Python.getInstance().getModule("backend")
                val task=async(Dispatchers.IO) { backend.callAttr("process_archive",zip.absolutePath,out.absolutePath,fonts.absolutePath,start,end,entries,maxPdfs,base,progress.absolutePath,selectedOriginalName).toString() }
                while(isActive && !task.isCompleted) {
                    val snap=withContext(Dispatchers.IO) { if(progress.isFile) runCatching { JSONObject(progress.readText()) }.getOrNull() else null }
                    if(snap!=null) sendProgress(snap.optDouble("percent",0.0).toInt(),snap.optString("message","Processing locally..."))
                    delay(350)
                }
                val result=JSONObject(task.await())
                if(!result.optBoolean("ok",false)) {
                    if(result.optString("error_code") == "already_processed") {
                        runOnUiThread { webView.evaluateJavascript("window.onNativeAlreadyProcessed();", null) }
                        return@launch
                    }
                    error(result.optString("error","Processing failed"))
                }
                val source=result.optJSONArray("paths") ?: JSONArray(); val paths=JSONArray()
                for(i in 0 until source.length()) { val f=File(source.getString(i)); if(f.isFile) paths.put(JSONObject().put("path",f.absolutePath).put("name",f.name)) }
                if(paths.length()==0) error("Processing completed, but no PDF files were produced.")
                val payload=JSONObject().put("paths",paths); val q=JSONObject.quote(payload.toString())
                runOnUiThread { webView.evaluateJavascript("window.onNativeComplete($q);",null) }
            } catch(e: Exception) { sendError(e.message ?: e.javaClass.simpleName) } finally { busy=false }
        }
    }
    private fun sendProgress(p:Int,m:String) { val q=JSONObject.quote(m); runOnUiThread { webView.evaluateJavascript("window.onNativeProgress(${p.coerceIn(0,100)},$q);",null) } }
    private fun sendError(m:String) { val q=JSONObject.quote(m); runOnUiThread { webView.evaluateJavascript("window.onNativeError($q);",null) } }
    private fun toastToPage(m:String) { val q=JSONObject.quote(m); webView.evaluateJavascript("(function(){var h=document.getElementById('hintBox');if(h)h.textContent=$q;})();",null) }
    private fun queryDisplayName(uri:Uri):String? { contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c -> if(c.moveToFirst()){val i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i)} }; return null }
    private fun copyAsset(path:String,dest:File) { if(dest.isFile&&dest.length()>0)return; assets.open(path).use { input -> dest.parentFile?.mkdirs(); dest.outputStream().use { input.copyTo(it) } } }
    override fun onDestroy() { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); super.onDestroy() }
}
