Add these two font files to app/src/main/assets/fonts/ before building/running:
- NotoSansDevanagari-Regular.ttf
- NotoSansDevanagari-Bold.ttf

The app copies them into its private files directory and passes that directory
into Build.py. The project intentionally does not include the font binaries.
