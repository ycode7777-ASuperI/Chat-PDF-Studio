"""Android-facing adapter for the existing Chat PDF Studio processing pipeline.

The extraction and PDF layout logic lives in Build.py. This module only handles
Android-friendly paths, progress snapshots, and a simple JSON result contract.
"""

import json
import os
import re
import traceback
import zipfile
from pathlib import Path
import sys
import types


def _prepare_pillow_for_android():
    """Preinstall a safe ImageCms fallback before any pipeline imports.

    Some Chaquopy Pillow builds do not include the native _imagingcms extension.
    Importing ImageCms first can leave a broken partial module in sys.modules.
    CMS is only needed for ICC colour-profile conversion; ordinary image decoding
    does not require it. This shim deliberately avoids importing PIL.ImageCms.
    """
    try:
        import PIL
        from PIL import Image  # noqa: F401
    except ImportError:
        # Do not conceal a failure in Pillow's core image support.
        return

    import sys
    import types

    cms = types.ModuleType("PIL.ImageCms")

    class PyCMSError(Exception):
        pass

    def _cms_unavailable(*args, **kwargs):
        raise PyCMSError(
            "ICC colour-profile conversion is unavailable in this Android build"
        )

    cms.PyCMSError = PyCMSError
    # fpdf2 may check these APIs; fail gracefully only if profile conversion is
    # actually requested. Normal JPEG/PNG decoding remains handled by Pillow.
    for name in (
        "getOpenProfile", "profileToProfile", "createProfile", "getProfileName",
        "getProfileInfo", "getDefaultIntent", "isIntentSupported", "buildTransform",
        "buildProofTransform", "applyTransform",
    ):
        setattr(cms, name, _cms_unavailable)

    # Force both `import PIL.ImageCms` and `from PIL import ImageCms` to resolve
    # to this fallback, even if an earlier import left a partial module behind.
    sys.modules["PIL.ImageCms"] = cms
    PIL.ImageCms = cms


_prepare_pillow_for_android()

from Build import main as run_pipeline


def _write_progress(progress_file, event):
    """Atomically replace a small JSON progress snapshot for Kotlin to poll."""
    if not progress_file:
        return
    path = Path(progress_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    payload = dict(event)
    temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def _safe_base_name(value):
    value = (value or "Generated_Report").strip()
    value = re.sub(r"[^\w\- .\u0900-\u097F]", "", value, flags=re.UNICODE)
    value = value.strip(" .")
    return (value or "Generated_Report")[:100]


def process_archive(
    zip_path,
    output_dir,
    font_dir,
    start_year=None,
    end_year=None,
    num_entries=None,
    max_pdfs=None,
    base_name="Generated_Report",
    progress_file=None,
    original_filename=None,
):
    """Run Build.main locally and return a JSON string for Kotlin.

    Kotlin should call this function from a background dispatcher, not the UI
    thread. Progress is written to progress_file for polling by the UI.
    """
    try:
        zip_path = str(Path(zip_path).resolve())
        output_dir = str(Path(output_dir).resolve())
        font_dir = str(Path(font_dir).resolve()) if font_dir else ""
        os.makedirs(output_dir, exist_ok=True)

        if not os.path.isfile(zip_path):
            raise FileNotFoundError("The selected ZIP file could not be found.")
        if not zip_path.lower().endswith(".zip"):
            raise ValueError("Please select a ZIP archive.")

        def report(event):
            _write_progress(progress_file, event)

        report({"stage": "starting", "percent": 0, "message": "Preparing local processing..."})
        # Keep one processed-name registry per original ZIP filename across app runs.
        # output_dir is .../chat_pdf_studio/jobs/<job-id>/output; parents[2] is
        # the stable chat_pdf_studio app-private directory.
        app_data_dir = Path(output_dir).parents[2]
        processed_names_dir = app_data_dir / "processed_names"
        paths = run_pipeline(
            zip_path=zip_path,
            source_folder=output_dir,
            num_of_entries=num_entries,
            max_pdfs=max_pdfs,
            start_year=start_year,
            end_year=end_year,
            base_name=_safe_base_name(base_name),
            progress_callback=report,
            max_workers=1,
            original_filename=original_filename or os.path.basename(zip_path),
            font_dir=font_dir,
            track_processed_names=True,
            processed_names_dir=str(processed_names_dir),
        )

        # One output remains a PDF. Multiple PDFs are bundled into one ZIP so the
        # user receives a single save prompt and all generated files together.
        paths = [str(Path(p).resolve()) for p in paths if Path(p).is_file()]
        if len(paths) > 1:
            archive_name = _safe_base_name(base_name) + ".zip"
            archive_path = str((Path(output_dir) / archive_name).resolve())
            with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                for pdf_path in paths:
                    archive.write(pdf_path, arcname=Path(pdf_path).name)
            paths = [archive_path]

        result = {"ok": True, "paths": paths, "errors": []}
        report({"stage": "done", "percent": 100, "message": "PDF generation complete.", "paths": result["paths"]})
        return json.dumps(result, ensure_ascii=False)
    except Exception as exc:
        message = str(exc) or exc.__class__.__name__
        already_processed = message.startswith("ALREADY_PROCESSED:")
        if already_processed:
            message = message.split(":", 1)[1]
        _write_progress(progress_file, {"stage": "error", "percent": 0, "message": message, "already_processed": already_processed})
        return json.dumps({"ok": False, "error": message, "error_code": "already_processed" if already_processed else "processing_error", "traceback": traceback.format_exc()}, ensure_ascii=False)
